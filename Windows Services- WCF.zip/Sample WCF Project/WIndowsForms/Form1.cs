﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WIndowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ClientWCFReference.Service1Client myClient = new ClientWCFReference.Service1Client();
            MessageBox.Show(myClient.GetData(123), "Services");
            myClient.Close();
        }
    }
}
